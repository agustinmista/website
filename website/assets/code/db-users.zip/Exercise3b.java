import java.sql.*;
import java.io.*;
import java.util.Properties;
import java.util.Scanner;

public class Exercise3b {
    static final String DATABASE = "jdbc:postgresql://localhost/agustin";
    static final String USERNAME = "agustin";
    static final String PASSWORD = "123";

    public static void main(String[] args) throws Exception {
        Class.forName("org.postgresql.Driver");
        Properties props = new Properties();
        props.setProperty("user",USERNAME);
        props.setProperty("password",PASSWORD);

        try (Connection conn = DriverManager.getConnection(DATABASE, props)) {
            Console console = System.console();
            String userinput;
            String query;
            PreparedStatement stmt;

            do {
                // ----------------------------------------
                // Ask for a user id

                System.out.print("> Enter user id: ");
                userinput = console.readLine();

                if (userinput.isEmpty()) continue;
                if (userinput.equals("q")) break;

                // ----------------------------------------
                // Build our query

                // // The bad way
                // query = "SELECT * FROM UserStatus WHERE id = " + userinput + "";
                // stmt = conn.prepareStatement(query);

                // The better way
                try {
                    query = "SELECT * FROM UserStatus WHERE id = ? ";
                    stmt = conn.prepareStatement(query);
                    stmt.setInt(1, Integer.parseInt(userinput));
                } catch (Exception e) {
                    System.out.println("Invalid input!");
                    continue;
                }

                // ----------------------------------------
                // Run the query and print the results
                ResultSet rs = stmt.executeQuery();

                if (!rs.next()) {
                    // Empty result
                    System.out.println("Nothing found");
                } else {
                    // Found some rows
                    do {
                        System.out.print("User " + rs.getString(1));
                        if (rs.getBoolean(2))
                            System.out.println(" is connected");
                        else
                            System.out.println(" is disconnected");
                    } while (rs.next());
                }
                System.out.println("The query was: " + stmt);
            } while (!userinput.equals("q"));

        } catch (SQLException e) {
            System.err.println(e);
            System.exit(2);
        }
    }
}
