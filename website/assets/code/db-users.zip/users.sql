-- Change this line with your user!
DROP OWNED BY agustin CASCADE;

CREATE TABLE Users
  ( id INTEGER PRIMARY KEY
  , name TEXT
  , password TEXT
  );

CREATE TABLE UserStatus
  ( id INTEGER PRIMARY KEY REFERENCES Users
  , loggedin BOOLEAN NOT NULL
  );

CREATE TABLE Logbook
  ( id INTEGER REFERENCES Users
  , timestamp TIMESTAMP
  , name TEXT
  , PRIMARY KEY (id, timestamp)
  );

INSERT INTO Users VALUES (11, 'Bob',    'bobby123');
INSERT INTO Users VALUES (24, 'Carl',   'pAsSwoRd');
INSERT INTO Users VALUES (55, 'Daniel', 'chalmers45');
INSERT INTO Users VALUES (74, 'Eve',    'dAtaBaSEs');

INSERT INTO UserStatus VALUES (11, TRUE);
INSERT INTO UserStatus VALUES (24, TRUE);
INSERT INTO UserStatus VALUES (55, FALSE);
INSERT INTO UserStatus VALUES (74, FALSE);


----------------------------------------
-- a)

-- First, you need to create a new user.
-- The easiest way is running the following command:
--> psql -U postgres -c 'CREATE ROLE Alice'

-- | Original privileges for Alice
-- GRANT SELECT(id, name, password)  ON Users      TO Alice;
-- GRANT SELECT(id, loggedin)        ON UserStatus TO Alice;
-- GRANT SELECT(id, timestamp, name) ON LogBook    TO Alice;
-- GRANT INSERT(id, timestamp, name) ON LogBook    TO Alice;

-- We want Alice to only have exactly the privileges that are necessary to
-- complete this SQL statement.
INSERT INTO LogBook
  SELECT u.id, TIMESTAMP '2017-01-10 14:00', u.name
  FROM (UserStatus us JOIN Users u ON us.id = u.id)
  WHERE us.loggedin = TRUE;

-- * Does Alice have too few, exactly enough, or too many privileges?
-- * What minimal set of permissions should she be granted instead, if not 
--   the same as listed above?

-- | Minimum set of privileges required for our query
GRANT SELECT(id, name)            ON Users      TO Alice;
GRANT SELECT(id, loggedin)        ON UserStatus TO Alice;
GRANT INSERT(id, timestamp, name) ON LogBook    TO Alice;
