import java.sql.*;
import java.io.*;
import java.util.Properties;
import java.util.Scanner;

public class Exercise3c {
    static final String DATABASE = "jdbc:postgresql://localhost/agustin";
    static final String USERNAME = "agustin";
    static final String PASSWORD = "123";

    public static void main(String[] args) throws Exception {
        Class.forName("org.postgresql.Driver");
        Properties props = new Properties();
        props.setProperty("user",USERNAME);
        props.setProperty("password",PASSWORD);

        try (Connection conn = DriverManager.getConnection(DATABASE, props)) {
            Console console = System.console();

            // -----------------------------------------
            // Exercise code

            // The JDBC code below is supposed to run a batch job in the
            // following way: Loop through an array of users, set each users
            // password hash to a certain value and add a logbook message for
            // that user. If any of the users do not exist, the whole batch job
            // should be rolled back. The queries seem to work fine, and if
            // there is an invalid id in the array the error message is printed,
            // but all the other ids in the array are still changed! What goes
            // wrong and how can it be fixed

            // Hint: two separate things need to be fixed, think about what
            // happens both before and after the error.


            int[] blockList = { 11, 24, 55 }; // Ids to be locked

            PreparedStatement update = conn.prepareStatement(
                "UPDATE Users SET password='qiyh4XPJGsOZ2MEAy' WHERE id=?");
            PreparedStatement insert = conn.prepareStatement(
                "INSERT INTO Logbook VALUES (?, now(), 'Account locked')");

            conn.setAutoCommit(false); // Enable transactions

            for(int user : blockList) { // For each user in blocklist ...

                update.setInt(1,user);
                insert.setInt(1,user);

                int res = update.executeUpdate();
                if (res == 0){ // 0 rows affected - user does not exist!
                    System.err.println("Error, missing id: " + user);
                    conn.rollback();
                    // If an id is invalid, we need to stop processing the 
                    // rest of them!
                    break; 
                } else {
                    insert.executeUpdate();
                    // We need to commit all the changes only after every id
                    // has been processed!
                    // conn.commit();
                }
            }
            conn.commit();

            // -----------------------------------------

        } catch (SQLException e) {
            System.err.println(e);
            System.exit(2);
        }
    }
}
